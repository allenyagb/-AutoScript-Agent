#!/bin/bash\necho "hello"
